# UBS Agent Version Lifecycle — Lifecycle-Hook Simulation POC (v2)

Companion code to `docs/ARCHITECTURE.md`. This version replaces the earlier
custom-controller POC entirely — there is **no controller process running
in this design at all**. Version transitions are driven purely by native
Kubernetes primitives: `postStart`/`preStop` container lifecycle hooks, a
`readinessProbe`, and `RollingUpdate` with `maxUnavailable: 0`.

Read `docs/ARCHITECTURE.md` first for the full design reasoning, and
`docs/DIAGRAM.md` for the Mermaid sequence diagrams. `docs/ALTERNATIVES-CONSIDERED.md`
holds the earlier controller-based design for reference.

## What this proves

1. A brand-new agent registers itself (mint + register against the mock
   UBS/Graph API) **before** it ever becomes `Ready` — enforced by the
   kubelet, not by any external process.
2. A version bump (re-applying the same Deployment with a new image) keeps
   the old pod fully serving until the new pod passes its own readiness
   check, then automatically deregisters and retires the old one — with
   zero controller, zero extra Kubernetes objects created or deleted
   beyond the pods Kubernetes itself churns through as part of a normal
   rolling update.
3. A **broken** new version never disrupts the old one — enforced entirely
   by native `maxUnavailable: 0` semantics, not by any code we wrote.

## Prerequisites

- [`kind`](https://kind.sigs.k8s.io/) and `kubectl`
- Docker

## 1. Create the local cluster

```bash
kind create cluster --name ubs-poc-v2
kubectl cluster-info --context kind-ubs-poc-v2
```

## 2. Build and load the images

```bash
# from the repo root
docker build -t ubs-poc/mock-api:latest ./mock-api
docker build -t ubs-poc/demo-agent:v1 -f demo-agent-image/Dockerfile ./demo-agent-image
docker build -t ubs-poc/demo-agent:v2 -f demo-agent-image/Dockerfile.v2 ./demo-agent-image

kind load docker-image ubs-poc/mock-api:latest --name ubs-poc-v2
kind load docker-image ubs-poc/demo-agent:v1 --name ubs-poc-v2
kind load docker-image ubs-poc/demo-agent:v2 --name ubs-poc-v2
```

## 3. Deploy the namespace, mock API, secret, scripts, and the agent itself

```bash
kubectl apply -f manifests/00-namespace.yaml
kubectl apply -f manifests/01-mock-api.yaml
kubectl apply -f manifests/05-blueprint-token-secret.yaml
kubectl apply -f manifests/06-lifecycle-scripts-configmap.yaml

kubectl -n ubs-poc-v2 rollout status deployment/mock-ubs-api

kubectl apply -f manifests/10-agent-deployment.yaml
kubectl -n ubs-poc-v2 rollout status deployment/stock-research-agent
```

Watch the agent pod's own logs (the hook scripts log directly to the
container's stdout, visible via normal pod logs — no separate controller
log to check):

```bash
kubectl -n ubs-poc-v2 logs -f deployment/stock-research-agent
```

## 4. Demo scenario A — first deploy

The `10-agent-deployment.yaml` apply above **is** scenario A. Expected log
output from the pod itself:

```
register-agent: attempt 1/10: minting agent id
register-agent: minted agent id=100
register-agent: registered agent id=100 against blueprint=bp-8891
```

Verify against the mock API directly:
```bash
kubectl -n ubs-poc-v2 port-forward svc/mock-ubs-api 5000:5000 &
curl -s http://localhost:5000/blueprint/bp-8891 | jq
# { "blueprintId": "bp-8891", "agentId": "100", "image": "ubs-poc/demo-agent:v1" }
```

Notice the pod only reaches `Ready` after this log line appears — check
with:
```bash
kubectl -n ubs-poc-v2 get pods -w
```

## 5. Demo scenario B — a clean version transition, zero controller involved

```bash
kubectl patch deployment stock-research-agent -n ubs-poc-v2 \
  --patch-file manifests/11-agent-v2-patch.yaml
```

Watch both the new pod come up and the old pod terminate:
```bash
kubectl -n ubs-poc-v2 get pods -w
```

**Expected sequence, purely from pod-level logs (`kubectl -n ubs-poc-v2 logs <new-pod>` then `<old-pod>`):**

New pod:
```
register-agent: attempt 1/10: minting agent id
register-agent: minted agent id=101
register-agent: registered agent id=101 against blueprint=bp-8891
```

Old pod (once the new one is Ready and Kubernetes scales old down):
```
deregister-agent: deregistering agent id=100
deregister-agent: agent id=100 deregistered successfully
```

Verify:
```bash
kubectl -n ubs-poc-v2 get pods
# only the v2 pod should remain

curl -s http://localhost:5000/blueprint/bp-8891 | jq
# { "blueprintId": "bp-8891", "agentId": "101", "image": "ubs-poc/demo-agent:v2" }

curl -s http://localhost:5000/_debug/state | jq
# retiredAgents should include "100"
```

Notice there is **no controller pod anywhere in this cluster** — check:
```bash
kubectl get deployments -A
# only mock-ubs-api and stock-research-agent exist
```

## 6. Demo scenario C — a broken push never disrupts the running agent

```bash
kubectl patch deployment stock-research-agent -n ubs-poc-v2 \
  --patch-file manifests/12-agent-v3-broken-patch.yaml
```

```bash
kubectl -n ubs-poc-v2 get pods
# NAME                                    READY   STATUS             RESTARTS
# stock-research-agent-xxxxxxxxxx-yyyyy   1/1     Running            0    <- old, still serving
# stock-research-agent-zzzzzzzzzz-wwwww   0/1     ImagePullBackOff   0    <- broken new pod
```

The old pod keeps serving indefinitely — this isn't something our scripts
enforce, it's `maxUnavailable: 0` on the Deployment doing exactly what it's
built to do. Confirm via the mock API that the registered agent hasn't
changed:
```bash
curl -s http://localhost:5000/blueprint/bp-8891 | jq
# still agentId 101 -- completely untouched
```

To "roll back," just patch the image back:
```bash
kubectl patch deployment stock-research-agent -n ubs-poc-v2 \
  --patch-file manifests/11-agent-v2-patch.yaml
```

## 7. Tear down

```bash
kind delete cluster --name ubs-poc-v2
```

## File map

```
mock-api/            Flask stand-in for UBS Blueprint API + Graph API
demo-agent-image/    Dockerfiles for the stand-in agent workload (v1/v2 + broken v3 notes)
scripts/             The two lifecycle hook scripts, fully commented reference copies
                      (the runtime versions embedded in
                      manifests/06-lifecycle-scripts-configmap.yaml are the same
                      logic, stripped of comments for a compact ConfigMap --
                      if you change the logic, update BOTH copies)
manifests/           Namespace, mock API, secret, scripts ConfigMap, agent Deployment,
                      and the two demo-scenario patches (clean v2, broken v3)
docs/
  ARCHITECTURE.md              Full design writeup (current, recommended design)
  DIAGRAM.md                   Mermaid sequence + comparison diagrams
  ALTERNATIVES-CONSIDERED.md   Earlier controller-based design, superseded, kept for record
```
