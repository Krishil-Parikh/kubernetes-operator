#!/bin/sh
# deregister-agent.sh
#
# Runs as the container's `preStop` lifecycle hook. Kubelet calls this the
# moment a pod is selected for termination (e.g. scaled down as part of a
# RollingUpdate), and BLOCKS actual container shutdown until this script
# exits (or terminationGracePeriodSeconds elapses, whichever comes first).
#
# This is what guarantees "old only stops after it's confirmed no longer
# needed" -- but note the ordering guarantee here is actually stronger and
# simpler than in a controller-based design: Kubernetes only starts
# terminating THIS pod once the NEW pod has already passed its own
# readinessProbe (that's what maxUnavailable: 0 enforces natively). So by
# the time preStop even runs, the new agent is already registered and
# serving. This script's only remaining job is cleanup: retire the OLD
# agent id so it doesn't linger as a duplicate registration.
#
# Required env vars: UBS_API_BASE, BLUEPRINT_TOKEN
# Reads the agent id this pod registered as, from the file
# register-agent.sh wrote at startup (/tmp/agent-id).

set -eu

MAX_ATTEMPTS=5
SLEEP_SECONDS=2

log() { echo "$(date -u +%Y-%m-%dT%H:%M:%SZ) deregister-agent: $*"; }

if [ ! -f /tmp/agent-id ]; then
  log "no /tmp/agent-id found -- this pod never successfully registered, nothing to deregister"
  exit 0
fi

AGENT_ID=$(cat /tmp/agent-id)
log "deregistering agent id=$AGENT_ID"

attempt=1
while [ "$attempt" -le "$MAX_ATTEMPTS" ]; do
  STATUS=$(curl -s -o /dev/null -w "%{http_code}" -X POST \
    "${UBS_API_BASE}/agents/${AGENT_ID}/deregister" \
    -H "Authorization: Bearer ${BLUEPRINT_TOKEN}" \
    -H "Content-Type: application/json" \
    -d '{}') || STATUS="000"

  if [ "$STATUS" = "200" ]; then
    log "agent id=$AGENT_ID deregistered successfully"
    exit 0
  fi

  log "attempt $attempt/$MAX_ATTEMPTS: deregister returned status=$STATUS, retrying"
  attempt=$((attempt + 1))
  sleep "$SLEEP_SECONDS"
done

# Deliberate design choice: we do NOT exit non-zero here. Blocking pod
# termination indefinitely because a cleanup call failed would itself
# become an availability problem (a pod stuck Terminating, holding
# resources). Instead: log loudly for alerting, and let the pod terminate.
# The result is a harmless orphaned registration (old agent id still shows
# as registered in UBS even though nothing is running for it), which is a
# monitoring/alerting concern, not a correctness or availability one --
# the NEW agent is already live and serving regardless of this outcome.
log "WARNING: failed to deregister agent id=$AGENT_ID after $MAX_ATTEMPTS attempts. " \
    "Pod will terminate anyway. This agent id needs manual/alerted cleanup in UBS."
exit 0
