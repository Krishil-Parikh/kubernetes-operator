#!/bin/sh
# register-agent.sh
#
# Runs as the container's `postStart` lifecycle hook. Kubelet calls this
# right after the container starts, and — critically — the pod is NOT
# marked Ready (and therefore gets NO traffic) until this script exits 0
# AND the readinessProbe passes. We make the readinessProbe depend on this
# script's own success marker, so there is no window where an unregistered
# pod can receive traffic.
#
# This is the entire "deployment" logic for a new agent version. There is
# no external controller involved -- this script IS the mechanism.
#
# Required env vars (injected via envFrom/Secret + Downward API, see
# manifests/10-agent-deployment.yaml):
#   UBS_API_BASE      - base URL of the UBS Blueprint + Graph API
#   BLUEPRINT_ID       - which blueprint this agent belongs to
#   BLUEPRINT_TOKEN    - auth token for the blueprint (real deployments only)
#   AGENT_IMAGE        - the image tag of THIS pod, used as the registered value
#
# Retry policy: since there is no external controller to retry a failed
# call later, this script owns its own bounded retry loop. If it never
# succeeds within MAX_ATTEMPTS, it exits non-zero -- kubelet then considers
# postStart failed and kills+restarts the container, which is the correct
# fail-safe: an agent that can never register must never go Ready.

set -eu

MAX_ATTEMPTS=10
SLEEP_SECONDS=3
READY_MARKER=/tmp/registered

log() { echo "$(date -u +%Y-%m-%dT%H:%M:%SZ) register-agent: $*"; }

attempt=1
while [ "$attempt" -le "$MAX_ATTEMPTS" ]; do
  log "attempt $attempt/$MAX_ATTEMPTS: minting agent id"

  MINT_RESPONSE=$(curl -sf -X POST "${UBS_API_BASE}/graph/agents" \
    -H "Authorization: Bearer ${BLUEPRINT_TOKEN}" \
    -H "Content-Type: application/json" \
    -d '{}') || { log "mint failed, retrying"; attempt=$((attempt + 1)); sleep "$SLEEP_SECONDS"; continue; }

  AGENT_ID=$(echo "$MINT_RESPONSE" | sed -n 's/.*"agentId":"\([^"]*\)".*/\1/p')
  if [ -z "$AGENT_ID" ]; then
    log "mint response had no agentId, retrying: $MINT_RESPONSE"
    attempt=$((attempt + 1)); sleep "$SLEEP_SECONDS"; continue
  fi
  log "minted agent id=$AGENT_ID"

  REGISTER_STATUS=$(curl -s -o /dev/null -w "%{http_code}" -X POST \
    "${UBS_API_BASE}/blueprint/${BLUEPRINT_ID}/register" \
    -H "Authorization: Bearer ${BLUEPRINT_TOKEN}" \
    -H "Content-Type: application/json" \
    -d "{\"agentId\":\"${AGENT_ID}\",\"image\":\"${AGENT_IMAGE}\"}") || REGISTER_STATUS="000"

  if [ "$REGISTER_STATUS" = "200" ]; then
    log "registered agent id=$AGENT_ID against blueprint=${BLUEPRINT_ID}"
    echo "$AGENT_ID" > /tmp/agent-id
    touch "$READY_MARKER"
    exit 0
  fi

  log "register call returned status=$REGISTER_STATUS, retrying"
  attempt=$((attempt + 1))
  sleep "$SLEEP_SECONDS"
done

log "FATAL: failed to register after $MAX_ATTEMPTS attempts -- refusing to become Ready"
exit 1
